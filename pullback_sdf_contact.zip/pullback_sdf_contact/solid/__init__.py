"""Solid mechanics helpers."""
