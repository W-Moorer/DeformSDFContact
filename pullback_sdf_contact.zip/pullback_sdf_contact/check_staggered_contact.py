import os

os.environ.setdefault("HWLOC_COMPONENTS", "-gl,-opencl,-cuda")

import numpy as np
import ufl
from dolfinx import fem

from config import MeshConfig, SDFConfig, SolidConfig, SolverConfig
from coupled_solver.staggered import (
    recommended_staggered_contact_options,
    solve_staggered_contact_step,
)
from mesh import tags
from mesh.build_mesh import create_reference_box
from post.xdmf import write_scalar_field
from sdf_field.boundary import create_sdf_bcs
from sdf_field.forms import sdf_forms
from sdf_field.spaces import create_sdf_space
from solid.boundary import create_solid_bcs
from solid.forms import solid_forms
from solid.spaces import create_displacement_space
from contact_geometry.slave_quadrature import build_slave_quadrature


def build_contact_state():
    mesh_cfg = MeshConfig(nx=4, ny=4, nz=4)
    solid_cfg = SolidConfig(E=100.0, nu=0.3, body_force_z=0.0)
    sdf_cfg = SDFConfig(beta=1e-6)
    solver_cfg = SolverConfig(max_it=6, verbose=True)
    penalty = 1.0

    domain, cell_tags, facet_tags = create_reference_box(mesh_cfg)
    V_u = create_displacement_space(domain, degree=1)
    V_phi = create_sdf_space(domain, degree=sdf_cfg.degree)

    u = fem.Function(V_u, name="u_contact")
    phi = fem.Function(V_phi, name="phi_contact")
    phi0 = fem.Function(V_phi, name="phi0_contact")

    phi0.interpolate(lambda x: x[2] - mesh_cfg.Lz)
    phi.interpolate(lambda x: x[2] - mesh_cfg.Lz)

    dx = ufl.Measure("dx", domain=domain)
    dx_band = ufl.Measure(
        "dx", domain=domain, subdomain_data=cell_tags, subdomain_id=tags.BAND
    )

    v_u = ufl.TestFunction(V_u)
    R_u_form, _ = solid_forms(u, v_u, solid_cfg, dx)
    solid_bcs = create_solid_bcs(V_u, facet_tags, top_uz=None)

    eta = ufl.TestFunction(V_phi)
    R_phi_form, K_phi_phi_form, K_phi_u_form = sdf_forms(
        u, phi, eta, phi0, sdf_cfg.beta, dx_band, dx_reg=dx
    )
    phi_bcs = create_sdf_bcs(V_phi, facet_tags, tags.TOP, phi_value=0.0)

    quadrature_points = build_slave_quadrature(domain, facet_tags, tags.TOP, quadrature_degree=2)

    state = {
        "domain": domain,
        "u": u,
        "phi": phi,
        "phi0": phi0,
        "R_u_form": R_u_form,
        "solid_bcs": solid_bcs,
        "R_phi_form": R_phi_form,
        "K_phi_phi_form": K_phi_phi_form,
        "K_phi_u_form": K_phi_u_form,
        "phi_bcs": phi_bcs,
        "quadrature_points": quadrature_points,
        "penalty": penalty,
        "slave_current_offset": np.array([0.0, 0.0, -0.04], dtype=np.float64),
    }
    return state, solver_cfg


def main():
    state, solver_cfg = build_contact_state()
    recommended = recommended_staggered_contact_options()

    if state["domain"].mpi_comm().rank == 0:
        print("Assembled staggered contact solve")
        print("")
        print(f"contact_structure_mode = {recommended['contact_structure_mode']}")
        print(f"max_outer_iter = {recommended['max_outer_iter']}")
        print(f"relaxation_u = {recommended['relaxation_u']}")
        print("")

    state, info = solve_staggered_contact_step(
        state,
        solver_cfg,
        {"step": 1, "load_value": 0.04},
        contact_structure_mode=recommended["contact_structure_mode"],
        max_outer_iter=recommended["max_outer_iter"],
        relaxation_u=recommended["relaxation_u"],
        relaxation_phi=recommended["relaxation_phi"],
        tol_du=recommended["tol_du"],
        tol_dphi=recommended["tol_dphi"],
        tol_contact_rhs=recommended["tol_contact_rhs"],
        verbose=solver_cfg.verbose,
    )

    phi_delta = state["phi"].vector.array_r - state["phi0"].vector.array_r
    if state["domain"].mpi_comm().rank == 0:
        print("")
        print("Final:")
        print(f"||u||_2 = {np.linalg.norm(state['u'].vector.array_r)}")
        print(f"||phi - phi0||_2 = {np.linalg.norm(phi_delta)}")
        print(f"active contact points = {info['active_contact_points']}")

    write_scalar_field(state["domain"], state["u"], "output_u_contact.xdmf")
    write_scalar_field(state["domain"], state["phi"], "output_phi_contact.xdmf")


if __name__ == "__main__":
    main()
