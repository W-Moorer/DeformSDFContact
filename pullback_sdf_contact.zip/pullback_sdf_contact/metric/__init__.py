"""Metric tensor helpers."""
