"""Contact geometry placeholders."""
